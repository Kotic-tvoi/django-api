# API_ShowPrice/management/commands/fetch_prices.py

from django.core.management.base import BaseCommand
from django.utils import timezone

from API_ShowPrice.models import PriceRecord
from API_ShowPrice.parser import ParseWB, partners  # dict {id: name}
from API_ShowPrice.pydantic_models import Items


def _rub_int(value) -> int:
    """Из копеек → ЦЕЛЫЕ рубли (округление к ближайшему)."""
    try:
        v = int(value)
    except Exception:
        return 0
    return (v + 50) // 100


def _try_init_parser(pid: int):
    """
    Самый безопасный порядок:
    1) без аргументов — ParseWB()
    2) если не получилось: позиционно со строкой/id
    3) в самом конце — именованные (seller_id=/partner_id=), т.к. ваш __init__ на них ругается

    затем мягко проставим возможные атрибуты (если есть).
    """
    sid = str(pid)

    # 1) без аргументов
    try:
        parser = ParseWB()
    except TypeError:
        parser = None

    # 2) позиционный (строка)
    if parser is None:
        try:
            parser = ParseWB(sid)
        except TypeError:
            parser = None

    # 3) позиционный (int)
    if parser is None:
        try:
            parser = ParseWB(pid)
        except TypeError:
            parser = None

    # 4) самые конфликтные — именованные (в вашем случае и дают "NoneType...")
    if parser is None:
        for kwargs in (
            {"seller_id": sid},
            {"partner_id": sid},
            {"seller": sid},
            {"partner": sid},
        ):
            try:
                parser = ParseWB(**kwargs)
                break
            except TypeError:
                parser = None

    if parser is None:
        raise TypeError("ParseWB could not be constructed with tolerant strategies")

    # Мягко пробуем задать атрибуты, если они существуют
    for attr in ("seller_id", "partner_id", "seller", "partner", "sellerId", "partnerId", "sellerid", "partnerid"):
        if hasattr(parser, attr):
            try:
                setattr(parser, attr, sid)
            except Exception:
                pass

    # Мягко пробуем вызвать сеттеры, если есть
    for m in ("set_seller_id", "set_partner_id", "set_seller", "set_partner"):
        if hasattr(parser, m):
            try:
                getattr(parser, m)(sid)
            except Exception:
                pass

    return parser


def _get_items(parser, pid: int) -> Items:
    """
    Резервные вызовы get_items:
    - get_items()
    - get_items(seller_id="..."), get_items(partner_id="..."), get_items(seller="..."), get_items(partner="...")
    """
    # 1) без аргументов
    try:
        return parser.get_items()
    except TypeError:
        pass
    sid = str(pid)
    # 2) набор именованных
    for kwargs in (
        {"seller_id": sid},
        {"partner_id": sid},
        {"seller": sid},
        {"partner": sid},
    ):
        try:
            return parser.get_items(**kwargs)
        except TypeError:
            continue
    # 3) позиционный
    try:
        return parser.get_items(sid)
    except TypeError:
        pass
    try:
        return parser.get_items(pid)
    except TypeError:
        pass
    # Если дошли сюда — отдаём явную ошибку
    raise TypeError("get_items could not be called with tolerant strategies")


class Command(BaseCommand):
    help = "Fetch current prices and store snapshots in DB (integer RUB, dest disabled)"

    def add_arguments(self, parser):
        parser.add_argument("--partner-id", type=int, help="Fetch only this partner_id")

    def handle(self, *args, **options):
        now = timezone.now()
        partner_ids = [options["partner_id"]] if options.get("partner_id") else list(partners.keys())
        total_rows = 0

        for pid in partner_ids:
            # 1) инициализация парсера
            try:
                parser = _try_init_parser(pid)
            except Exception as e:
                self.stderr.write(self.style.ERROR(f"Parser init failed for partner {pid}: {e}"))
                continue

            # 2) получаем товары
            try:
                items: Items = _get_items(parser, pid)
            except Exception as e:
                self.stderr.write(self.style.ERROR(f"Failed to fetch items for partner {pid}: {e}"))
                continue

            # 3) собираем батч в БД
            batch = []
            for product in getattr(items, "products", []):
                try:
                    size0 = product.sizes[0]
                    basic = _rub_int(getattr(size0.price, "basic", 0))
                    product_price = _rub_int(getattr(size0.price, "product", 0))
                    item_id = int(product.id)
                    name = (product.name or "")[:255]
                except Exception:
                    continue

                batch.append(PriceRecord(
                    created_at=now,        # единая метка времени — один «снимок»
                    partner_id=pid,
                    dest="",               # регионы отключены
                    item_id=item_id,
                    item_name=name,
                    price_basic=basic,     # ЦЕЛЫЕ рубли
                    price_product=product_price,
                ))

            if batch:
                PriceRecord.objects.bulk_create(batch, ignore_conflicts=True)
                total_rows += len(batch)

        self.stdout.write(self.style.SUCCESS(
            f"Saved ~{total_rows} rows at {now:%Y-%m-%d %H:%M:%S} (partners={len(partner_ids)})"
        ))
