from django.shortcuts import render
from django.db.models import Q
from django.core.paginator import Paginator
from django.http import HttpResponse
import csv
import re

from .models import PriceRecord
from .forms import PriceFilterForm


def price_history_view(request):
    form = PriceFilterForm(request.GET or None)
    qs = PriceRecord.objects.all()

    if form.is_valid():
        partner = form.cleaned_data.get("partner")
        date_from = form.cleaned_data.get("date_from")
        date_to = form.cleaned_data.get("date_to")
        item_mode = form.cleaned_data.get("item_mode")
        item_ids_raw = form.cleaned_data.get("item_ids")

        if partner:
            qs = qs.filter(partner_id=int(partner))
        if date_from:
            qs = qs.filter(created_at__gte=date_from)
        if date_to:
            qs = qs.filter(created_at__lte=date_to)

        # если выбран режим "selected", фильтруем по списку item_id
        if item_mode == "selected" and item_ids_raw:
            parts = [p.strip() for p in re.split(r"[\s,]+", item_ids_raw) if p.strip()]
            try:
                ids = [int(p) for p in parts]
                qs = qs.filter(item_id__in=ids)
            except Exception:
                pass
        # если item_mode == "all" — фильтр по item_id не накладываем

    qs = qs.select_related(None).only(
        "created_at", "partner_id", "dest", "item_id", "item_name", "price_basic", "price_product"
    )

    # Экспорт в Excel
    if request.GET.get("export") == "xlsx":
        try:
            from openpyxl import Workbook
        except Exception:
            resp = HttpResponse("openpyxl not installed. Run: pip install openpyxl", content_type="text/plain; charset=utf-8")
            resp.status_code = 500
            return resp
        wb = Workbook()
        ws = wb.active
        ws.title = "price_history"
        headers = ["created_at", "partner_id", "dest", "item_id", "item_name", "price_basic", "price_product"]
        ws.append(headers)
        for r in qs.iterator(chunk_size=2000):
            ws.append([r.created_at, r.partner_id, r.dest, r.item_id, r.item_name, r.price_basic, r.price_product])
        from io import BytesIO
        buf = BytesIO()
        wb.save(buf)
        buf.seek(0)
        resp = HttpResponse(buf.read(), content_type="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet")
        resp["Content-Disposition"] = 'attachment; filename="price_history.xlsx"'
        return resp

    # Экспорт в CSV
    if request.GET.get("export") == "csv":
        resp = HttpResponse(content_type="text/csv; charset=utf-8")
        resp["Content-Disposition"] = 'attachment; filename="price_history.csv"'
        writer = csv.writer(resp)
        writer.writerow(["created_at", "partner_id", "dest", "item_id", "item_name", "price_basic", "price_product"])
        for r in qs.iterator(chunk_size=2000):
            writer.writerow([r.created_at, r.partner_id, r.dest, r.item_id, r.item_name, r.price_basic, r.price_product])
        return resp

    paginator = Paginator(qs, 200)  # 200 строк/страница
    page = request.GET.get("page")
    page_obj = paginator.get_page(page)

    return render(request, "API_ShowPrice/price_history.html", {"form": form, "rows": page_obj})
